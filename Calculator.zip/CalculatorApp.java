import java.util.*;

/**
 * Title: Week 5 Project - Application Delivery
 * Name: Corey Potts
 * Date: 7/22/2025
 */
public class CalculatorApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Memory memory = new Memory();
        boolean running = true;

        System.out.println("\nWelcome to the Java Calculator\n");

        while (running) {
            try {
                // Display menu options
                System.out.println("\nChoose an operation:");
                System.out.println("1. Add");
                System.out.println("2. Subtract");
                System.out.println("3. Multiply");
                System.out.println("4. Divide");
                System.out.println("5. Show Memory");
                System.out.println("6. Recall Memory");
                System.out.println("Type 'q' to quit at any time\n");
                System.out.print("Enter choice: ");
                String choice = scanner.nextLine();
                
                if (choice.equalsIgnoreCase("q")) {
                    running = false;
                    break;
                }

                switch (choice) {
                    case "1":
                    case "2":
                    case "3":
                    case "4":
                        // Prompt user for multiple numbers
                        List<Double> numbers = new ArrayList<>();
                        System.out.println("Enter numbers separated by space:");
                        String[] inputs = scanner.nextLine().split(" ");
                        for (String input : inputs) {
                            if (input.equalsIgnoreCase("q")) {
                                running = false;
                                break;
                            }
                            numbers.add(Double.parseDouble(input));
                        }
                        if (!running) break;

                        // Perform selected operation
                        double result = 0;
                        switch (choice) {
                            case "1": result = Calculator.add(numbers); break;
                            case "2": result = Calculator.subtract(numbers); break;
                            case "3": result = Calculator.multiply(numbers); break;
                            case "4": result = Calculator.divide(numbers); break;
                        }

                        // Display result and store in memory
                        System.out.printf("Result: %.2f%n", result);
                        memory.store(result);
                        break;

                    case "5":
                        memory.showMemory();
                        break;

                    case "6":
                        System.out.print("Enter memory index (1-10): ");
                        int index = Integer.parseInt(scanner.nextLine());
                        Double recalled = memory.recall(index);
                        if (recalled != null) {
                            System.out.printf("Recalled value: %.2f%n", recalled);
                        }
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Please try again.");
            } catch (ArithmeticException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }

        System.out.println("Thank you for using the calculator. Goodbye");
        scanner.close();
    }
}