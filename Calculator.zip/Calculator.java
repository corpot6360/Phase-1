import java.util.List;

/**
 * Utility class for performing arithmetic operations.
 */
class Calculator {

    // Adds all numbers in the list.
    public static double add(List<Double> numbers) {
        double sum = 0;
        for (double num : numbers) sum += num;
        return sum;
    }

    // Subtracts all subsequent numbers from the first number.
    public static double subtract(List<Double> numbers) {
        double result = numbers.get(0);
        for (int i = 1; i < numbers.size(); i++) result -= numbers.get(i);
        return result;
    }

    // Multiplies all numbers in the list.
    public static double multiply(List<Double> numbers) {
        double result = 1;
        for (double num : numbers) result *= num;
        return result;
    }

    // Divides the first number by all subsequent numbers.
    // Throws ArithmeticException if division by zero occurs.
    public static double divide(List<Double> numbers) throws ArithmeticException {
        double result = numbers.get(0);
        for (int i = 1; i < numbers.size(); i++) {
            if (numbers.get(i) == 0) throw new ArithmeticException("Error: Cannot divide by zero.");
            result /= numbers.get(i);
        }
        return result;
    }
}
