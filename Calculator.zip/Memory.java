import java.util.ArrayList;
import java.util.List;

/**
 * Class to manage memory storage for calculator results.
 * Stores up to 10 values and allows recall by index.
 */
class Memory {
    private final List<Double> memory = new ArrayList<>();

    // Stores a value in memory. If memory is full, removes the oldest value.
    public void store(double value) {
        if (memory.size() >= 10) {
            memory.remove(0);
        }
        memory.add(value);
    }

    // Displays all stored values with their index.
    public void showMemory() {
        if (memory.isEmpty()) {
            System.out.println("Memory is empty.");
        } else {
            System.out.println("Stored values:");
            for (int i = 0; i < memory.size(); i++) {
                System.out.printf("%d: %.2f%n", i + 1, memory.get(i));
            }
        }
    }

    // Recalls a value from memory by index.
    public Double recall(int index) {
        if (index < 1 || index > memory.size()) {
            System.out.println("Invalid memory index.");
            return null;
        }
        return memory.get(index - 1);
    }
}