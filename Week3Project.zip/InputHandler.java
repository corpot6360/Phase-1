import java.util.Scanner;

/**
 * Utility class for handling user input.
 */
public class InputHandler {
    private static final Scanner scanner = new Scanner(System.in);

    // Prompts the user for an integer input.
    public static int getInt(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. " + prompt);
            scanner.next();
        }
        return scanner.nextInt();
    }
}