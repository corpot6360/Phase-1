import java.util.ArrayList;

/**
 * Utility class to manage a collection of up to 10 integer values in memory.
 */
public class MemoryCollection {
    private final ArrayList<Integer> values = new ArrayList<>();

    // Adds a value to the collection.
    public void addValue() {
        if (values.size() < 10) {
            int val = InputHandler.getInt("Enter value to add: ");
            values.add(val);
            System.out.println("Value added.");
        } else {
            System.out.println("Memory full. Max 10 values.");
        }
    }

    // Displays all values in the collection.
    public void displayValues() {
        System.out.println("Stored values: " + values);
    }

    // Displays the count of values in the collection.
    public void displayCount() {
        System.out.println("Count: " + values.size());
    }

    // Removes a specific value from the collection.
    public void removeValue() {
        int val = InputHandler.getInt("Enter value to remove: ");
        if (values.remove((Integer) val)) {
            System.out.println("Value removed.");
        } else {
            System.out.println("Value not found.");
        }
    }

    // Calculates and displays the sum of all values.
    public void sumValues() {
        int sum = MathOperations.sum(values);
        System.out.println("Sum: " + sum);
    }

    // Calculates and displays the average of all values.
    public void averageValues() {
        double avg = MathOperations.average(values);
        System.out.println("Average: " + avg);
    }

    // Calculates and displays the difference between the first and last values.
    public void differenceFirstLast() {
        if (values.size() >= 2) {
            int diff = values.get(0) - values.get(values.size() - 1);
            System.out.println("Difference (first - last): " + diff);
        } else {
            System.out.println("Need at least two values.");
        }
    }
}