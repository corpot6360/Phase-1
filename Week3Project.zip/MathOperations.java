import java.util.List;

/**
 * Utility class for performing mathematical operations.
 */
public class MathOperations {
    
    // Calculates the sum of a list of integers.
    public static int sum(List<Integer> list) {
        return list.stream().mapToInt(Integer::intValue).sum();
    }

    // Calculates the average of a list of integers.
    public static double average(List<Integer> list) {
        if (list.isEmpty()) return 0;
        return sum(list) / (double) list.size();
    }
}