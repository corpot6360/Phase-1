/**
 * Title: Week 2 Project - Java Calculator with Menu
 * Name: Corey Potts
 * Date: 7/8/2025
 * 
 * Main application class for the Memory Calculator.
 */
public class Main {
    public static void main(String[] args) {
        
        // 
        Display.printHeader("Project Week 3", "Arrays and Lists", "Corey Potts");
        Display.printWelcome();

        SingleMemory singleMemory = new SingleMemory();
        MemoryCollection memoryCollection = new MemoryCollection();

        boolean running = true;
        while (running) {
            Display.printMenu();
            int choice = InputHandler.getInt("\nEnter your choice: ");

            switch (choice) {
                case 1 -> singleMemory.storeValue();
                case 2 -> singleMemory.retrieveValue();
                case 3 -> singleMemory.clearValue();
                case 4 -> singleMemory.replaceValue();
                case 5 -> memoryCollection.addValue();
                case 6 -> memoryCollection.displayValues();
                case 7 -> memoryCollection.displayCount();
                case 8 -> memoryCollection.removeValue();
                case 9 -> memoryCollection.sumValues();
                case 10 -> memoryCollection.averageValues();
                case 11 -> memoryCollection.differenceFirstLast();
                case 0 -> {
                    running = false;
                    Display.printGoodbye();
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}