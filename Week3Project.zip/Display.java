/**
 * Utility class for displaying messages and menus to the user.
 */
public class Display {
    
    // Display header
    public static void printHeader(String week, String title, String name) {
        System.out.println("\n-------------------------------------------------");
        System.out.println("Project Week 3 Arrays and Lists");
        System.out.println("Name: Corey Potts");
        System.out.println("-------------------------------------------------\n");
    }

    // Display welcome message and basic instructions
    public static void printWelcome() {
        System.out.println("Welcome to the Memory Calculator");
        System.out.println("You can store and manipulate numbers in memory.");
    }

    // Display menu options
    public static void printMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Store single value");
        System.out.println("2. Retrieve single value");
        System.out.println("3. Clear single value");
        System.out.println("4. Replace single value");
        System.out.println("5. Add value to collection");
        System.out.println("6. Display all values");
        System.out.println("7. Display count");
        System.out.println("8. Remove a value");
        System.out.println("9. Sum of values");
        System.out.println("10. Average of values");
        System.out.println("11. Difference (first - last)");
        System.out.println("0. Quit");
    }

    // Display goodbye message
    public static void printGoodbye() {
        System.out.println("Thank you for using the Memory Calculator. Goodbye.");
    }
}